#!/bin/bash
##############################################################################
# HPE Deployment Automation - Bootstrap setup.sh
#
# (C) Copyright 2020-2021 Hewlett Packard Enterprise Development LP
#
# Author :  Avinash Jalumuru <avinash.jalumuru@hpe.com>
# Commit :  9c2f9d7
# Date   :  2023-10-09
#
##############################################################################


echo 'Deployment Automation - Bootstrap'
echo

function usage() {
   echo "Usage: $0 [clean]  [clean awx] [clean gitlab] [clean nginx] [download] [prereqs]"
   echo
   echo 'Purpose: This script installs the Bootstrap utility and its dependencies'
   echo
   echo "optional arguments:"
   echo " -h, --help    shows this help message and exit"
   echo " clean         removes all the configuration done by setup"
   echo " clean awx     removes the configurations done for awx"
   echo " clean nginx   removes the configurations done for nginx"
   echo " clean gitlab  removes the configurations done for gitlab"
   echo " download      to download required packages and images"
   echo " prereqs       to check the system prerequisites"
   echo
}

export OS=$(cat /etc/os-release | grep -i NAME= | head -1 | tr -d '"' | awk -F '=' '{ print $2 }')
export VERSION_ID=$(cat /etc/os-release | grep -i VERSION_ID= | head -1 | tr -d '"' | awk -F '=' '{ print $2 }')
export INSTALL_DIR=/opt/hpe
export LOG_DIR=/var/log/hpe/Bootstrap
export repo_dir=/repository1
export HOSTIP=$(hostname -I | awk '{ print $1 }')
export da_user=hpeda
export virtual_env=hpeda-2.0
export temp_dir=/tmp
export da_version=v2.0
export selinux_version=0.3.0
export bootstrap_config_file=$INSTALL_DIR/Bootstrap/$da_version/bootstrap_config.cfg
export setup_log_file=$LOG_DIR/setup.log
export PYTHON_VER=3.9
declare -A min_reqs=( ['/opt']=10 ['/var']=50 ['/var/tmp']=15 ['/usr']=35 ['/']=45 )
export download_completion_log=$repo_dir/.download_status
export GREEN='\033[0;32m'
export NC='\033[0m'
export RED='\033[0;31m'
export YELLOW='\033[0;33m'

# Python and pip packages are verified exclusively and are not added to REQUIRED_RPMS
REQUIRED_RPMS=("jq" "wget" "podman")
export DA_WORKING_DIR=$(dirname ${bootstrap_config_file})

mkdir -p ${LOG_DIR}
echo "$(date +%F_%T) - Begin Bootstrap" >> ${setup_log_file}

function install_required_setup() {

    if [ ! -d ${repo_dir} ]; then
        mkdir -p ${repo_dir}
    fi

    installed_python=0
    missing_rpms=()
    existing_python_info=$(python3 --version 2>/dev/null)
    existing_python_version=$(echo "${existing_python_info}" | cut -d' ' -f2 | cut -d'.' -f1-2)
    if [ $PYTHON_VER != $existing_python_version ]; then
      missing_rpms+=("python${PYTHON_VER}")
      installed_python=1
    fi

    echo -n "If pip is installed, it is available in the path : " | tee -a ${setup_log_file}
    which pip${PYTHON_VER} &>/dev/null
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}pip package ${NC}not present. Adding to missing packages"
        # Different OS uses different uses package name for pip, so not generalizing
        # Example: rhel8 (python39-pip) and rhel9 (python3-pip)
        missing_rpms+=("python3-pip")
    fi

    for rpm in "${REQUIRED_RPMS[@]}"; do
      if ! rpm -qa | grep -qw "${rpm}"; then
        missing_rpms+=("${rpm}")
      fi
    done

    if [ ${#missing_rpms[@]} -eq 0 ]; then
        echo -e "${GREEN}Required folder already with rpms ${NC}" | tee -a ${setup_log_file}
    else
        echo
        echo "Installing mandatory packages for setup"  | tee -a ${setup_log_file}
        echo -e "Packages to be installed ${YELLOW}${missing_rpms[@]}${NC}" | tee -a ${setup_log_file}
        if [ ! -f ${download_completion_log} ]; then
            mkdir -p "${repo_dir}/base_rpms"
            sudo -E yum install -y ${missing_rpms[@]} --downloadonly --downloaddir=${repo_dir}/base_rpms
            sudo cp -rf ${repo_dir}/base_rpms/*.rpm ${repo_dir}
        fi

        sudo -E yum install --disablerepo="*" ${repo_dir}/*.rpm -y
        if [ $? -ne 0 ]; then
          echo -e "${RED}Mandatory Packages installation got failed ${NC}"
          exit 1
        fi

        if [ $installed_python -eq 1 ]; then
           sudo update-alternatives --set python3 /usr/bin/python${PYTHON_VER}  2>/dev/null
        fi
        echo -e "${GREEN}Successfully installed mandatory packages for setup${NC}"  | tee -a ${setup_log_file}
    fi
}

function create_user() {

   if grep -q "$da_user" /etc/passwd  >/dev/null 2>&1; then
      chown -R $da_user:$da_user $LOG_DIR
      echo -e "${GREEN}$da_user is already created ${NC}" | tee -a $setup_log_file

   else
      echo
      echo "Creating new user $da_user" | tee -a $setup_log_file
      useradd -G wheel $da_user  >/dev/null 2>&1
      #creating new user for DA and adding the same in wheel group for sudo access
      useradd -G wheel $da_user  >/dev/null 2>&1
      #updating sudoers file to use wheel group users by without password by validating the sudoers file
      if ! grep -q '^%wheel.*NOPASSWD' /etc/sudoers; then
         sed -i 's/^%wheel/#%wheel/' /etc/sudoers
         sed -i 's/^# %wheel/%wheel/' /etc/sudoers
      fi
      chown -R $da_user:$da_user $LOG_DIR

   fi
}

function create_venv() {

   echo "Creating virtual env" >> $setup_log_file
   # Create a virtual environment
   python3 -m venv $INSTALL_DIR/Bootstrap/$da_version/$virtual_env --system-site-packages

   # Install any required packages by activating virtual environment
   source $INSTALL_DIR/Bootstrap/$da_version/$virtual_env/bin/activate
}


function supported_os() {


  echo -n "Checking for supported OS ..."

  if [[ "$OS" = "Red Hat Enterprise Linux" ]]; then
    echo "yes"
  elif [[ "$OS" = "Rocky Linux" ]]; then
    echo "yes"
  else
    echo "no"
    exit 1
  fi
}

function setup_hostname() {
  # Used to identify the self-signed certificate
  echo ""
  name=`hostname`
  if [[ $name == "localhost" || $name == "localhost.localdomain" ]]
  then

        while [[ -z "$new_hostname" ]]
        do
          read -ep "Hostname : " new_hostname

          if [[ -z $new_hostname ]]; then
            echo -e "${RED}Hostname not provided ${NC}" | tee -a $setup_log_file
            exit
          fi

          if [[ "$new_hostname" == *"_"* ]]; then
            echo -e "${RED}hostname is not valid, please use hostname without '_' ${NC}" | tee -a $setup_log_file
            exit
          else
            echo -e "${GREEN}hostname is valid ${NC}" | tee -a $setup_log_file
          fi
        done

        echo -e "${YELLOW}Updating hostname to : $new_hostname ${NC}" | tee -a $setup_log_file
        sudo hostnamectl set-hostname $new_hostname
        sudo sed -ie 's/"hostname": .*"/"hostname": '\"${new_hostname}\"'/g' $bootstrap_config_file

        if [[ $? -eq 0 ]]; then
           echo -e "\n\nHostname change updated immediately.\nCurrent shell will not reflect this without a logon.\nVerify by executing command hostname" | tee -a $setup_log_file
         else
            echo -e "${RED}Hostname setting failed ${NC}" | tee -a $setup_log_file
        fi
  fi
}


function proxy() {

  FOUND=$(grep http_proxy /etc/environment)

  # Multiple export variable check for GIT_PYTHON_REFRESH
  FOUNDGIT=$(grep GIT_PYTHON_REFRESH /etc/environment)

  if [[ -z "$FOUNDGIT" ]]; then
     sudo sh -c "echo 'export GIT_PYTHON_REFRESH=quiet' >> /etc/environment"
  fi

  if [[ -z "$FOUND" ]]; then
     echo
     # Request for proxy variable if any
     read -ep "HTTP Proxy   : " web_proxy

     host="127.0.0.1,localhost,${HOSTIP}"

     if [[ -z "$web_proxy" ]]; then
       echo "http_proxy not provided" | tee -a $setup_log_file
     else
       sudo sh -c "echo 'export http_proxy=$web_proxy' >> /etc/environment"
       sudo sh -c "echo 'export https_proxy=$web_proxy' >> /etc/environment"
       sudo sh -c "echo 'export no_proxy=$host' >> /etc/environment"
       echo -e "${YELLOW}Proxy set to : $web_proxy ${NC}" | tee -a $setup_log_file
       web_proxy="${web_proxy//\//\\\/}"
       sed -ie 's/"proxy": .*"/"proxy": '\"${web_proxy}\"'/g' $bootstrap_config_file
     fi
     # Set this attribute irrespective of Proxy or not
     # echo "export GIT_PYTHON_REFRESH=quiet" >>/etc/environment
  else
     echo
     echo -e "${GREEN}Proxy set in /etc/environment ${NC}" | tee -a $setup_log_file
     echo
     # reset local variables for the script to execute
     http_proxy=$(grep http_proxy /etc/environment | awk -F= '{ print $2 }')
     https_proxy=$(grep https_proxy /etc/environment | awk -F= '{ print $2 }')
     no_proxy=$(grep no_proxy /etc/environment | awk -F= '{ print $2 }')
     export no_proxy=$no_proxy
  fi
}


function initialize_bootstrap() {

    echo
    echo "Initializing Bootstrap configuration" | tee -a $setup_log_file
    echo
    # bootstrap_config_file=$INSTALL_DIR/Bootstrap/$da_version/bootstrap_config.cfg
    #/opt/hpe/Bootstrap/$da_version/

    temp_dir=$(mktemp -d)
    files_to_move=0
    bootstrap=`realpath Bootstrap.tar.gz` #updating path to temp_dir

    if [[ -f  "${bootstrap_config_file}" ]]; then
      echo
      echo -e "${GREEN}Bootstrap config already exists ${NC}" | tee -a $setup_log_file
      echo

    #
    elif [[ -f "$bootstrap" ]]; then
      echo
      echo -e "${YELLOW}Bootstrap.tar.gz found in local path. Extracting ...${NC}" | tee -a $setup_log_file
      tar -zxf $bootstrap -C ${temp_dir}
      echo
      files_to_move=1

    #
    elif [[ -d ${DA_WORKING_DIR} ]]; then
      cd ${DA_WORKING_DIR}
      bootstrap=`realpath Bootstrap.tar.gz` #updating path to temp_dir
      echo
      echo -e "${YELLOW}Bootstrap.tar.gz found in $DA_WORKING_DIR. Extracting ...${NC}" | tee -a $setup_log_file
      echo
      tar -zxf $temp_dir/$bootstrap -C $temp_dir
      files_to_move=1
    fi

    if [ 1 -eq ${files_to_move} ]; then
      # Move this to the install directory

      echo -e "${YELLOW}Installing to: ${DA_WORKING_DIR} ${NC}" | tee -a $setup_log_file
      echo

      # create the directory
      mkdir -p ${DA_WORKING_DIR}

      # move the Bootstrap directory there
      mv $temp_dir/Bootstrap/* ${DA_WORKING_DIR}

      # move Bootstrap zip to ${DA_WORKING_DIR}
      \mv Bootstrap.tar.gz  ${DA_WORKING_DIR}
      
      # move the Script_inventory directory to ${DA_WORKING_DIR}
      \mv Script_inventory ${DA_WORKING_DIR}

      PLAYBOOKS=$(ls -A *Ansible*Playbooks*.tar.gz 2>/dev/null)
      if [ ! -z "$PLAYBOOKS" ]; then
         \mv  $PLAYBOOKS ${DA_WORKING_DIR}
      fi

      echo -e "${GREEN}Transfer of bootstrap files to ${DA_WORKING_DIR} completed ${NC}" >> $setup_log_file

    fi
}


function assign_permissions() {

    if grep -q "$da_user" /etc/passwd  >/dev/null 2>&1; then
       sudo chown -R $da_user:$da_user $(dirname $LOG_DIR)
       sudo chown -R $da_user:$da_user $INSTALL_DIR
       sudo chown -R $da_user:$da_user $repo_dir
       echo "Assigning permissions to $INSTALL_DIR and $repo_dir" >> $setup_log_file
    fi

}

function extract_zip() {

  pip3 install selinux==$selinux_version --find-links=$repo_dir/requirements/ --no-index

  #activating virtual env
  source $INSTALL_DIR/Bootstrap/$da_version/$virtual_env/bin/activate

     echo -e "${GREEN}Installing rpms from $repo_dir ${NC}" | tee -a $setup_log_file
     sudo yum install --disablerepo="*" -y ${repo_dir}/*.rpm  | tee -a $setup_log_file

     # change to extracted dir
     cd ${DA_WORKING_DIR}

     #changed python ver to latest
     if [[ -f /usr/bin/python${PYTHON_VER} ]]; then
        sudo update-alternatives --set python3 /usr/bin/python${PYTHON_VER}  2>/dev/null
     else
        echo -e "${RED}python${PYTHON_VER} not found ${NC}" | tee -a $setup_log_file
     fi

     # install python dependencies
     if [ -f "$PWD/requirements.txt" ]; then
        # upgrade pip first
        echo
        echo -e "${YELLOW}Upgrading pip...${NC}" | tee -a $setup_log_file
        echo

        python3 -m pip install -U pip --find-links=$repo_dir/requirements/ --no-index | tee -a $setup_log_file

        echo
        echo -e "${GREEN}Installing Python Packages ... ${NC}" | tee -a $setup_log_file

        pip3 install wheel --find-links=$repo_dir/requirements/ --no-index | tee -a $setup_log_file
        pip3 install -U -r $PWD/requirements.txt pip --find-links=$repo_dir/requirements/ --no-index | tee -a $setup_log_file


        if [ $? -eq 0 ]; then
           echo
           print_next
           echo
        else
           echo -e "${RED}ERROR: Failed to install python dependencies from requirements.txt ${NC}" | tee -a $setup_log_file
        fi
     fi

     # Change back to /opt/hpe/Bootstrap/$da_version location
     cd ${DA_WORKING_DIR}

     # update url_home replace bootstrap.url.com with system IP address
     sed -i "s/bootstrap.url.com/${HOSTIP}/g" $PWD/bootstrap_config.cfg

     # Create log and cert directories
     if [[ ! -d "$LOG_DIR" ]]; then
        mkdir -p $LOG_DIR
        sudo chown -R $da_user:$da_user $(dirname $LOG_DIR)
     fi

     if [[ ! -d "${DA_WORKING_DIR}/certs" ]]; then
        mkdir -p ${DA_WORKING_DIR}/certs
     fi

     # Create the right path's
     FIND_PYPATH=$(grep 'export PYTHONPATH' /etc/environment)

     if [[ -z "$FIND_PYPATH" ]]; then
        PYPATH="export PYTHONPATH=${DA_WORKING_DIR}/modules:$PYTHONPATH"
        sudo sh -c "echo '$PYPATH' >> /etc/environment"
     fi

     FIND_ALIAS=$(grep 'bootstrap.me' /etc/environment)

     if [[ -z "$FIND_ALIAS" ]]; then
        SHORTCUT="alias bootstrap.me=\"sudo ${DA_WORKING_DIR}/$virtual_env/bin/python3 ${DA_WORKING_DIR}/bootstrap.py\""
        sudo sh -c "echo '$SHORTCUT' >> /etc/environment"
     fi

     # Adding the usbCustomIso.sh and ks_to_floppy.sh scripts to path
     FIND_SCRIPT_ENV=$(grep 'Script_inventory' /etc/environment)

     if [[ -z "$FIND_SCRIPT_ENV" ]]; then
        UPD_PATH="export PATH=\"$PATH:${DA_WORKING_DIR}/Script_inventory/CustomIso/\""
        sudo sh -c "echo '$UPD_PATH' >> /etc/environment"
     fi


     # Adding /usr/local/bin to PATH if not exist in /etc/environment
     PATH_IN_ENV=$(grep "export PATH=" /etc/environment )
     FIND_LOCAL_BIN=$(echo $PATH_IN_ENV | grep "/usr/local/bin")
     if [[ -z "$FIND_LOCAL_BIN" ]]; then
         NEW_PATH_IN_ENV="${PATH_IN_ENV::-1}:/usr/local/bin\""
         sudo sed -i  "s|$PATH_IN_ENV|$NEW_PATH_IN_ENV|g" /etc/environment
     fi

     rm -rf $INSTALL_DIR/Bootstrap/$da_version/bootstrap_config.cfge
}


# Function to check disk usage
check_disk_usage() {
echo "Checking minimum disk requirements"
for dir in "${!min_reqs[@]}"; do
   min=${min_reqs[$dir]}
   usage=$(df -BG $dir | awk 'NR==2{print $4}' | sed 's/G//')
   if (( usage < min )); then
      echo -e "${RED}WARNING: Available space for $dir is less than $min GB! ${NC}" | tee -a $setup_log_file
      exit
   fi
done
}

# check_ram() {
#   mem=$(free | awk '/^Mem:/{print $2}')
#   if (( $mem >= 8000000 )); then
#     true #echo "System has 8GB or more of RAM"
#   else
#     echo "System has less than 8GB of RAM"
#     exit 1
#   fi
# }



function da_upgrade() {

   echo "DA upgrade is in process, Getting postgress container information...."
   #storing postgres container name
   postgress_cont_name=`docker ps -a --format "{{.Names}}" | grep postgres`

   echo -e "${YELLOW}DA upgrade - Getting postgres container name $postgress_cont_name ${NC}"

   #generating awx postgres container dump
   docker exec -it $postgress_cont_name /bin/bash -c '
   cd /var/lib/postgresql/data/
   pg_dump -U awx > awx_backup.sql'

   awx_backup=$?
   if [ $awx_backup -ne 0 ]; then
      echo -e "${RED}AWX backup failed, kindly check awx containers... ${NC}"
      exit 1
   fi

   #generating container id
   container_id=`docker ps --filter name=postgres |  awk '{ print $1 }' | tail  -1`

   mkdir -p $INSTALL_DIR/hpeda/v1.0.3_backup

   #copy sql backup file from container to host
   docker cp $container_id:/var/lib/postgresql/data/awx_backup.sql $INSTALL_DIR/hpeda/v1.0.3_backup/

   #Shutdown the docker service
   systemctl stop docker
   systemctl disable docker
   yum remove docker-ce -y

   #podman is not able to pull some image after removing docker, updating environment variable to emulate docker socket
   export DOCKER_HOST=unix:///var/run/docker.sock

   host_name=`hostname -I | awk '{print $1}'`

   #reading vault file to get gitlab creds
   vault_data=`ansible-vault view /opt/hpe/Bootstrap/infra_credentials.yml --vault-password-file /opt/hpe/Bootstrap/vault_pass.json`
   gitlab_user=$(jq -r '.config.credentials.gitlab_user' <<< "$vault_data")
   gitlab_password=$(jq -r '.config.credentials.gitlab_password' <<< "$vault_data")
   repo_url="https://$gitlab_user:$gitlab_password@$host_name:9443/root/HPE-Deployment-Automation.git"

   #disable ssl verification
   git config --global http.sslVerify false

   org_path=$PWD
   git clone $repo_url
   git_status=$?
   if [ $git_status -ne 0 ]; then
      echo -e "${RED}Gitlab backup failed, kindly check gitlab configurations... ${NC}"
      exit 1
   fi

   cd HPE-Deployment-Automation

   for branch in `git branch -a | grep remotes | grep -v HEAD | grep -v master`;
   do
      repos+=($branch)
   done

   for repo in "${repos[@]}"; do
      git switch `basename $repo`
      git branch
      mkdir -p $INSTALL_DIR/hpeda/v1.0.3_backup/v103_packages
      mv /repository1/* /opt/hpe/hpeda/v1.0.3_backup/v103_packages 2>/dev/null
      mkdir -p $INSTALL_DIR/hpeda/v1.0.3_backup/`basename $repo`
      cp -r * $INSTALL_DIR/hpeda/v1.0.3_backup/`basename $repo`
   done

   #shutdown the GitLab service
   gitlab-ctl stop

   #shutdown nginx service
   systemctl stop nginx
   systemctl disable nginx

   mv $INSTALL_DIR/Script_inventory $INSTALL_DIR/hpeda/v1.0.3_backup 2>/dev/null
   echo -e "${GREEN}DA upgrade - Backup got completed.... ${NC}"

   cd $org_path
   mv $INSTALL_DIR/Bootstrap/bootstrap_config.cfg  $INSTALL_DIR/Bootstrap/bootstrap_config.cfg_old

   sed -i '/PYTHONPATH/d; /bootstrap.me/d; /PATH/d' /etc/environment 2>/dev/null

}

function upgrade_check() {

   #checking version of DA if its already installed
   if [[ -f /opt/hpe/Bootstrap/bootstrap_config.cfg ]]; then
      current_version=`grep -v '^#' /opt/hpe/Bootstrap/bootstrap_config.cfg 2>/dev/null | jq -r '.config.ansible_playbooks.version'`
      if [ "$current_version" == "v1.0.3" ]; then
         echo -ne "${YELLOW}Do you want to proceed with an upgrade of all the components (yes/no)? ${NC}"
         read upgrade_response
         echo
         if [[ "$upgrade_response" == "yes" ]]; then
            echo -e "${YELLOW}In upgrade process default nginx path will change to ${RED}'/usr/share/nginx' ${NC}"          
            echo -e "${YELLOW}Kindly move/copy the webserver files in ${GREEN}/usr/share/nginx ${NC}"
            echo
            echo -ne "${YELLOW}Do you want to proceed (yes/no)? ${NC}"
            read nginx_backup_resp
            if [[ "$nginx_backup_resp" == yes ]]; then
              da_upgrade #calling upgrade function to take backup of gitlab repo & awx postgres db
            else
              echo -e "${RED}Take backup of nginx '/usr/share/nginx/html' then proceed with upgrade process ${NC}"
              exit
            fi
         elif [[ "$upgrade_response" == "no" ]]; then
            echo -e "${GREEN}thanks for the input we are not upgrading it to $da_version ${NC}" | tee -a $setup_log_file
            exit
         else
            echo -e "${RED}Please enter yes/no ${NC}" | tee -a $setup_log_file
            exit 1
         fi
      fi
   else
     echo "v1.0.3 installation not found" | tee -a $setup_log_file
   fi

}


function prereqs() {

   not_found=0

   # calling disk usage function to check space prerequistes
   check_disk_usage


   if [[ ! -d "$LOG_DIR" ]]; then
        mkdir -p $LOG_DIR
        sudo chown -R $da_user:$da_user $(dirname $LOG_DIR)
   fi

   #to check /repo1 dir
   repo_dir=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.local_repo'`
   if [ -d "$repo_dir" ]; then
      echo -e "${GREEN}prereqs: $repo_dir is present ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      echo -e "${RED}$repo_dir not found ${NC}" | tee -a $setup_log_file
      echo
      echo -e "${RED}ERROR: Missing $repo_dir directory ${NC}" | tee -a $setup_log_file
      echo
      echo -e "${YELLOW}Please proceed with './setup.sh download' or './setup.sh' ${NC}" | tee -a $setup_log_file
      echo
      exit
   fi

   #check /repository1/requirements present or not
   if [ -d "$repo_dir/requirements" ]; then
      echo -e "${GREEN}prereqs: $repo_dir/requirements is present ${NC}" >> $setup_log_file
   else
      echo -e "${RED}$repo_dir/requirements not found ${NC}"  | tee -a $setup_log_file
      echo
      echo -e "${RED}ERROR: Missing $repo_dir/requirements directory ${NC}" | tee -a $setup_log_file
      echo
      echo -e "${YELLOW}Please proceed with './setup.sh download' or './setup.sh' ${NC}" | tee -a $setup_log_file
      echo
      exit
   fi


   #to check requirement.txt file
   python_dep=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.python_dependencies'`
   if [ -f "$python_dep" ]; then
      echo -e "${GREEN}prereqs: Found pip requirements file at $python_dep ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      list_pkgs+=("Missing python requirements file\n")
      list_pkgs+=($python_dep)
      echo -e "${RED}prereqs: ERROR: pip requirements $python_dep not present ${NC}" >> $setup_log_file
   fi

   #checking tar/whl files of pip packages exists or not
   req_content=`cat $python_dep`
   pkgs=$(echo "$req_content" | awk -F'[==<=]' '{print $1}')
   list_pkgs+=("\n** Missing python dependencies **")
   for pkg in $pkgs
   do
     package_pattern="${pkg//-/[_-]}"
     #if (ls $repo_dir/requirements/${package_pattern}*.tar.gz 2>/dev/null | grep -w $package_pattern >/dev/null) || (ls $repo_dir/requirements/${package_pattern}*.whl 2>/dev/null | grep -w $package_pattern >/dev/null) || (ls $repo_dir/requirements/${package_pattern}*.zip 2>/dev/null | grep -w $package_pattern >/dev/null); then
     count_if_any=`find $repo_dir/requirements -iname ${package_pattern}* | wc -l` >/dev/null 2>&1
     if (( $count_if_any > 0 ))  ; then
       echo -e "${GREEN}prereqs: Found pip package ${pkg} in $repo_dir/requirements ${NC}" >> $setup_log_file
     else
       not_found=$((not_found+1))
       list_pkgs+=($pkg)
       echo -e "${RED}prereqs: ERROR: pip package ${pkg} not present in $repo_dir/requirements ${NC}" >> $setup_log_file
     fi
   done


   #check condition for k3s binary
   k3s_bin=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.binary'`
   bin_file=$(basename $k3s_bin)
   if [ -f "$repo_dir/$bin_file" ]; then
       echo -e "${GREEN}prereqs: Found k3s binary $repo_dir/$bin_file ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      list_pkgs+=($bin_file)
      echo -e "${RED}prereqs: ERROR: Missing k3s binary $bin_file in $repo_dir ${NC}" >> $setup_log_file
   fi

   #check condition for k3s tar
   k3s_airgap=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.airgap'`
   airgap_tar=$(basename $k3s_airgap)
   if [ -f "$repo_dir/$airgap_tar" ]; then
       echo -e "${GREEN}prereqs: Found k3s airgap package $repo_dir/$airgap_tar ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      list_pkgs+=($airgap_tar)
      echo -e "${RED}prereqs: ERROR: Missing k3s airgap package $airgap_tar in $repo_dir ${NC}" >> $setup_log_file
   fi

   #check condition for k3s install.sh
   k3s_script=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.install_script'`
   script=$(basename $k3s_script)
   if [ -f "$repo_dir/$script" ]; then
       echo -e "${GREEN}prereqs: Found k3s script at $repo_dir/$script ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      list_pkgs+=($script)
      echo -e "${RED}prereqs: ERROR: Missing k3s script $script in $repo_dir ${NC}" >> $setup_log_file
   fi

   #check condition for k3s-selinux rpm packages
   k3s_selinux_path=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s."k3s-selinux"'`
   k3s_selinux_package=$(basename $k3s_selinux_path)
   if [ -f "$repo_dir/$k3s_selinux_package" ]; then
       echo -e "${GREEN}prereqs: Found linux package at $repo_dir/$k3s_selinux_package ${NC}" >> $setup_log_file
   else
      not_found=$((not_found+1))
      list_pkgs+=($k3s_selinux_package)
      echo -e "${RED}prereqs: ERROR: Missing k3s package $k3s_selinux_package in $repo_dir ${NC}" >> $setup_log_file
   fi

   #checking rpm files
   list_pkgs+=("\n** Check for YUM RPMs **")
   yum_dependencies=( $(grep -v '^#' $bootstrap_config_file | jq -r '.setup.yum_dependencies[]' | tr -d '"') )
   for package in ${yum_dependencies[@]}
   do
     if [[ -n $(find "$repo_dir" -maxdepth 1 -name "${package}*.rpm") ]]; then
       echo -e "${GREEN}prereqs: yum package ${package} available in $repo_dir ${NC}" >> $setup_log_file
     else
       if rpm -q ${package} >/dev/null; then
         echo -e "${GREEN}prereqs: yum package ${package} already installed ${NC}" >> $setup_log_file
       else
         not_found=$((not_found+1))
         list_pkgs+=($package)
         echo -e "${RED}prereqs: ERROR: Missing yum package ${package} in $repo_dir ${NC}" >> $setup_log_file
       fi
     fi
   done


   #conditions to check images
   list_pkgs+=("\n** Check for Container images **")
   container_images=( $(grep -v '^#' $bootstrap_config_file | jq -r '.config[].components | .[] | (.registry + ":" + .tag)') )
   for i in ${container_images[@]}
   do
     registry_entry=$(basename $i)
     image_file_name=${registry_entry/:/_}
     if [ -f "$repo_dir/${image_file_name}.tar" ]; then
         echo -e "${GREEN}prereqs: container registry ${i} available in $repo_dir ${NC}" >> $setup_log_file
     else
        not_found=$((not_found+1))
        list_pkgs+=(${image_file_name}.tar)
        echo -e "${RED}prereqs: ERROR: Missing container image ${image_file_name} in $repo_dir ${NC}" >> $setup_log_file
     fi
   done


   echo
   if [ $not_found == 0 ]; then
      echo -e "${GREEN}All prerequistes are present.... ${NC}" | tee -a $setup_log_file
   else
      echo -e "${RED}List of prerequistes not found in $repo_dir ${NC}" | tee -a $setup_log_file
      for item in "${list_pkgs[@]}"; do
        echo -e "${item}" | tee -a $setup_log_file
      done
      echo
      echo -e "${YELLOW}Download all the packages/images using 'download' option if proxy enabled or place the downloaded packages/images in $repo_dir ${NC}" | tee -a $setup_log_file
      exit
   fi

}

function download_dependencies() {

    if [ -f ${download_completion_log} ];
    then
        echo
        echo -e "${GREEN}Download already completed. Skipping.. ${NC}" | tee -a $setup_log_file
        echo
        return
    fi

    # Source the environment to enable proxy if present
    . /etc/environment

    if curl -s --max-time 2 -I http://google.com >/dev/null 2>&1; then

      repo_dir=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.local_repo'`

      #creating /repository1 directory and its subsequent directorys
      echo "Repository name from config file is ${repo_dir}" >> $setup_log_file

      if [ ! -d "$repo_dir" ]; then
         mkdir -p $repo_dir
      fi

      if [ ! -d "$repo_dir/requirements" ]; then
         mkdir -p $repo_dir/requirements
      fi

     if [[ -f /usr/bin/python${PYTHON_VER} ]]; then
        sudo update-alternatives --set python3 /usr/bin/python${PYTHON_VER}  2>/dev/null
     fi

      download_completion_status=0
      k3s_bin=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.binary'`
      k3s_airgap=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.airgap'`
      k3s_script=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.install_script'`
      k3s_selinux_path=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s."k3s-selinux"'`
      kustomize_bin=`grep -v '^#' $bootstrap_config_file | jq -r '.setup."kustomize"."binary"'`

      echo
      echo

      if cat $setup_log_file | grep "k3s prerequistes downloaded successfully" >/dev/null 2>&1; then
         echo -e "${GREEN}k3s files already download, skipping files download part ${NC}" | tee -a $setup_log_file
      else
         echo -e "${YELLOW}Downloading k3s dependencies${NC}" | tee -a $setup_log_file

         wget $k3s_airgap -nc -c -P $repo_dir
         airgap_status=$?
         wget $k3s_bin -nc -c -P $repo_dir
         k3s_bin_status=$?
         wget $k3s_script  -nc -c -P $repo_dir
         k3s_script_status=$?
         wget $k3s_selinux_path -nc -c -P $repo_dir
         k3s_selinux_status=$?
         wget $kustomize_bin -nc -c -P $repo_dir
         kustomize_status=$?

         if [[ "$OS" = "Rocky Linux"  && "$VERSION_ID" == "9.0" ]]; then
            container_pkg=`grep -v '^#' $bootstrap_config_file | jq -r '.setup."container-selinux"."centos-stream9"'`            
            wget $container_pkg -nc -c -P $repo_dir
            container_selinux_status=$?
            if [ $container_selinux_status -eq 0 ]; then
               echo -e "${GREEN}Container-selinux package downloaded successfully ${NC}" | tee -a $setup_log_file
            else
               echo -e "${RED}ERROR: Container-selinux package not downloaded, try again.... ${NC}" | tee -a $setup_log_file
            fi
         fi

         if [ $airgap_status -eq 0 ] && [ $k3s_bin_status -eq 0 ] && [ $k3s_script_status -eq 0 ] && [ $k3s_selinux_status -eq 0 ] && [ $kustomize_status -eq 0 ]; then
            echo -e "${GREEN}k3s prerequistes downloaded successfully ${NC}" | tee -a $setup_log_file
         else
            echo -e "${RED}ERROR: Some of k3s files are not downloaded, try again.... ${NC}" | tee -a $setup_log_file
            download_completion_status=$((download_completion_status+1))
         fi
      fi

      echo

      if cat $setup_log_file | grep "images got save in $repo_dir successfully...." >/dev/null 2>&1; then
         echo -e "${GREEN}Images already downloaded in $repo_dir ${NC}" | tee -a $setup_log_file
      else
         registry_ret_status=0
         container_images=( $(grep -v '^#' $bootstrap_config_file | jq -r '.config[].components | .[] | (.registry + ":" + .tag)') )

         echo -e "${YELLOW}Downloading required container images${NC}" | tee -a $setup_log_file
         for image in ${container_images[@]}
         do
            registry_entry=$(basename $image)
            image_file_name=${registry_entry/:/_}

            echo
            echo -e "${YELLOW}Pulling and saving container image: ${GREEN}${registry_entry} ${NC}"
            podman pull ${image}
            ret_status=$?
            registry_ret_status=$((registry_ret_status+ret_status))
            if [ $ret_status -ne 0 ]; then
               echo -e "${RED}${image} image not pulled ${NC}" | tee -a $setup_log_file
               continue
            fi

            podman save ${image} > $repo_dir/${image_file_name}.tar
            ret_status=$?
            registry_ret_status=$((registry_ret_status+ret_status))
            if [ $ret_status -ne 0 ]; then
               echo -e "${RED}${image} image not saved ${NC}" | tee -a $setup_log_file
            fi
         done

         if [ $registry_ret_status -eq 0 ]; then
            echo -e "${GREEN}Images got save in $repo_dir successfully.... ${NC}" | tee -a $setup_log_file
         else
            echo -e "${RED}ERROR: Some of the container images are not pulled properly, try again.... ${NC}" | tee -a $setup_log_file
            download_completion_status=$((download_completion_status+1))
         fi

      fi

      echo
      if cat $setup_log_file | grep "rpm files downloaded successfully" >/dev/null 2>&1; then
         echo -e "${GREEN}rpm files already downloaded ${NC}" | tee -a $setup_log_file
      else
         #installing yum packages
         yum_dependencies=( $(grep -v '^#' $bootstrap_config_file | jq -r '.setup.yum_dependencies[]' | tr -d '"') )
         sudo -E yum install -y ${yum_dependencies[@]}  --downloadonly --downloaddir=$repo_dir --allowerasing

         if [ $? -eq 0 ]; then
            echo -e "${GREEN}rpm files downloaded successfully ${NC}" | tee -a $setup_log_file
         else
            echo -e "${RED}ERROR: Some of the rpm files are not downloaded, try again to download..... ${NC}" | tee -a $setup_log_file
            download_completion_status=$((download_completion_status+1))
         fi
      fi

      echo
      if cat $setup_log_file | grep "pip packages downloaded successfully" >/dev/null 2>&1; then
         echo -e "${GREEN}pip depedencies already downloaded ${NC}" | tee -a $setup_log_file
      else

         #download pip packages and yum packages
         cd ${INSTALL_DIR}/Bootstrap/$da_version

         sudo -E python3 -m pip download pip -d $repo_dir/requirements
         pip_status=$?
         sudo -E pip3 download wheel selinux==$selinux_version -d $repo_dir/requirements
         wheel_status=$?
         sudo -E pip3 download -r $PWD/requirements.txt -d $repo_dir/requirements
         req_status=$?

         if [ $pip_status -eq 0 ] && [ $wheel_status -eq 0 ] && [ $req_status -eq 0 ]; then
            echo -e "${GREEN}pip packages downloaded successfully ${NC}" | tee -a $setup_log_file
         else
            echo -e "${RED}ERROR: Some of the pip packages are not downloaded, try again.... ${NC}" | tee -a $setup_log_file
            download_completion_status=$((download_completion_status+1))
         fi
      fi

      if [ ${download_completion_status} -eq 0 ];
      then
        echo -e "${GREEN}All the components downloaded successfully ${NC}" | tee -a $setup_log_file
        touch $download_completion_log
      fi
   else
      echo -e "${RED}\nERROR: No internet connection. Please check your network settings and try again later. ${NC}" | tee -a $setup_log_file
      echo
      exit
   fi

}


function k3s_deploy() {

   #activating virtual env
   source $INSTALL_DIR/Bootstrap/$da_version/$virtual_env/bin/activate

   INSTALL_DIR=/opt/hpe
   #checking if k8s is already installed or not
   k8s_deployed=`cat $bootstrap_config_file | grep -v '^#' | jq '.setup.k8s_cluster.deployed'`
   echo

   if [  -f "/usr/local/bin/k3s" ]; then
      echo -e "${GREEB}K3s is already installed..... ${NC}" | tee -a $setup_log_file
      sudo sh -c "echo 'export KUBECONFIG=/etc/rancher/k3s/k3s.yaml' >> /etc/environment"
   elif [[ $k8s_deployed == true ]]; then
       k8s_config_path=`cat $bootstrap_config_file | grep -v '^#' | jq '.setup.k8s_cluster.kube_config_path'`
       sudo sh -c "echo 'export KUBECONFIG=$k8s_config_path' >> /etc/environment"
       echo -e "${GREEN}k8s is already deployed, no need to deploy k3s..... ${NC}" | tee -a $setup_log_file
   elif [[ $k8s_deployed == false ]]; then              
      echo -e "${YELLOW}Installing k3s....${NC}"  | tee -a $setup_log_file
      repo_dir='/repository1'
      #changing permission of k3s install script
      k3s_script=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.install_script'`
      script=$(basename $k3s_script)
      sudo chmod +x $repo_dir/$script

      k3s_airgap=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s.airgap'`
      airgap_tar=$(basename $k3s_airgap)

      sudo gunzip -k $repo_dir/$airgap_tar

      echo -e "${YELLOW}installing k3s selinux package.... ${NC}" | tee -a $setup_log_file
      k3s_selinux_path=`grep -v '^#' $bootstrap_config_file | jq -r '.setup.k3s."k3s-selinux"'`
      container_pkg=`grep -v '^#' $bootstrap_config_file | jq -r '.setup."container-selinux"."centos-stream9"'`
      kustomize_bin=`grep -v '^#' $bootstrap_config_file | jq -r '.setup."kustomize"."binary"'`
      container_pkg_name=$(basename $container_pkg)
      k3s_selinux_package=$(basename $k3s_selinux_path)
      kustomize_bin_name=$(basename $kustomize_bin)
      if [[ "$OS" = "Rocky Linux"  && "$VERSION_ID" == "9.0" ]]; then
         sudo yum -y remove  container-selinux
         sudo yum -y install ${repo_dir}/$container_pkg_name
      fi
      sudo rpm -i $repo_dir/$k3s_selinux_package

      #moving k3s related packages/files to k3s config directories
      echo "Copy k3s airgap files and binaries" >> $setup_log_file
      sudo mkdir -p /var/lib/rancher/k3s/agent/images/
      airgap_images_tar=`echo $airgap_tar | rev | cut -c4- | rev`
      sudo cp $repo_dir/$airgap_images_tar /var/lib/rancher/k3s/agent/images/
      sudo cp $repo_dir/k3s /usr/local/bin/k3s
      sudo chmod +x /usr/local/bin/k3s
      sudo tar -zxf $repo_dir/$kustomize_bin_name -C ${repo_dir}
      sudo cp $repo_dir/kustomize /usr/local/sbin/kustomize

      #running k3s install script
      INSTALL_K3S_SKIP_DOWNLOAD=true INSTALL_K3S_SKIP_SELINUX_RPM=true INSTALL_K3S_SELINUX_WARN=true sh /repository1/$script

      k3s_deployment_status=$?
      if [ $k3s_deployment_status -eq 0 ]; then
         echo
         echo -e "${GREEN}K3S installed successfully.... ${NC}"  | tee -a $setup_log_file
         echo
      else
         echo -e "${RED}K3s deployment failed, kindly check the configuration.... ${NC}" | tee -a $setup_log_file
         exit 1
      fi

      sudo sh -c "echo 'export KUBECONFIG=/etc/rancher/k3s/k3s.yaml' >> /etc/environment"

      #disable firewalld service
      echo "Stop and disable firewall" >> $setup_log_file
      sudo systemctl stop firewalld 2> /dev/null
      sudo systemctl disable firewalld 2> /dev/null

      sleep 15
      echo

      #configuration changes to metric server deployment
      sudo sed -i '/args/a \        - --kubelet-insecure-tls' /var/lib/rancher/k3s/server/manifests/metrics-server/metrics-server-deployment.yaml  2> /dev/null
      sudo kubectl apply -f /var/lib/rancher/k3s/server/manifests/metrics-server/metrics-server-deployment.yaml 2> /dev/null
      echo "Apply metrics server deployment for k3s" >> $setup_log_file

      #changing permissions of /etc/rancher as general user won't be able to access to config files
      sudo chown -R $da_user:$da_user /etc/rancher

      local_path=$(grep /usr/local/bin /etc/environment)
      if [[ -z $local_path ]]; then
         sed -i 's#^export PATH="\(.*\)"$#export PATH="\1:/usr/local/bin"#' /etc/environment 2> /dev/null
      fi

   fi
}

function cleanup() {
   echo -n "."
   echo -n "."

   if [[ $# -eq 1 ]]; then

      # Cleanup proxy settings
      sudo sed -i '/export http_proxy.*/d' /etc/environment
      sudo sed -i '/export PATH.*/d' /etc/environment
      sudo sed -i '/export https_proxy.*/d' /etc/environment
      sudo sed -i '/export no_proxy.*/d' /etc/environment
      sudo sed -i '/export GIT_PYTHON_REFRESH.*/d' /etc/environment
      sudo sed -i '/export PYTHONPATH.*/d' /etc/environment
      sudo sed -i '/alias bootstrap.me.*/d' /etc/environment

   fi

   if [[ $# -eq 1 || $2 = "awx" ]]; then

      awx_pods=`kubectl get pod -n hpeda 2>/dev/null | grep awx | wc -l`
      if [[ $awx_pods > 0 ]]; then
         echo -e "${YELLOW}Removing AWX resources ${NC}" | tee -a $setup_log_file

         cd $INSTALL_DIR/Bootstrap/$da_version/awx_automation

         #running ansible playbook to undeploy awx
         ansible-playbook -i hosts awx.yaml --tags undeploy

         #removing staging directory for AWX
         rm -rf $INSTALL_DIR/awx
      else
         echo -e "${GREEN}AWX is already deleted.... ${NC}"
      fi

   fi


   if [[ $# -eq 1 || $2 = "gitlab" ]]; then

      gitlab_pods=`kubectl get pod -n hpeda 2>/dev/null | grep gitlab | wc -l`
      if [[ $gitlab_pods > 0 ]]; then
         echo -e "${YELLOW}Removing gitlab resources ${NC}" | tee -a $setup_log_file

         cd $INSTALL_DIR/Bootstrap/$da_version/gitlab_automation

         #running ansible playbook to undeploy gitlab
         ansible-playbook -i hosts gitlab_playbook.yml --tags undeploy

         #removing staging directory for gitlab
         rm -rf $INSTALL_DIR/gitlab/
      else
         echo -e "${GREEN}Gitlab is already deleted... ${NC}"
      fi

   fi

   if [[ $# -eq 1 || $2 = "nginx" ]]; then

      nginx_pods=`kubectl get pod -n hpeda 2>/dev/null | grep nginx | wc -l`
      if [[ $nginx_pods > 0 ]]; then

         echo -e "${YELLOW}Removing nginx resources ${NC}" | tee -a $setup_log_file

         cd $INSTALL_DIR/Bootstrap/$da_version/nginx_automation

         #running ansible playbook to undeploy nginx
         ansible-playbook -i hosts nginx_automation.yml --tags undeploy

         #removing staging directory for nginx
         rm -rf $INSTALL_DIR/nginx
      else
         echo -e "${GREEN}Nginx is already deleted... ${NC}"
      fi

   fi

   if [[ $# -eq 1 && $2 = "" ]]; then

      #moving tar files to original dir
      #checking Ansible_playbook tar

      #removing k3s
      if [  -f "/usr/local/bin/k3s" ]; then
         /usr/local/bin/k3s-uninstall.sh
         echo -e "${GREEN}K3s removed successfully... ${NC}"
      else
         echo -e "${GREEN}k3s already deleted.. ${NC}"
      fi
      if [ -f /opt/hpe/Ansible_Playbooks.tar.gz ]; then
              echo "moving ansible playbook tar to original directory...."
              mv $INSTALL_DIR/Ansible_Playbooks.tar.gz $PWD
      else
         echo  -e "${RED}Ansible playbooks tar is non-existent ${NC}"
      fi

      #checking bootstrap tar
      if [ -f /opt/hpe/Bootstrap.tar.gz ]; then
              echo "moving bootstrap tar to original directory...."
              mv $INSTALL_DIR/Bootstrap.tar.gz $PWD
      else
         echo -e "${RED}Bootstrap tar is non-existent ${NC}"
      fi

      rm -rf $PWD/Ansible_Playbooks

      #cleaning certificates
      echo "Cleaning certificates...."

      if [[ -d certs ]]; then
         rm -rf certs
      fi

      #cleaning Bootstrap config files, git repo  and other stuffs

      if [ -d "$bootstrap_config_file" ]; then
         rm -rf bootstrap_config.cfg
      fi

      if [ -f "$INSTALL_DIR/Bootstrap/$da_version/custom_packages.txt" ]; then
         rm -rf $INSTALL_DIR/Bootstrap/$da_version/custom_packages.txt
      fi


      if [ -d "$INSTALL_DIR/Bootstrap/$da_version/download" ]; then
         rm -rf $INSTALL_DIR/Bootstrap/$da_version/download
      fi

      if [ -d "$INSTALL_DIR/git_repo" ]; then
         rm -rf git_repo
      fi

      if [ -f "$INSTALL_DIR/index.html" ]; then
         rm -rf index.html
      fi

      if [ -f "$INSTALL_DIR/Bootstrap/$da_version/infra_credentials.yml" ]; then
         rm -rf infra_credentials.yml
      fi

      if [[ -d $LOG_DIR ]]; then
         rm -rf $LOG_DIR/*
         rmdir $LOG_DIR
      fi


      # cleanup the Bootstrap directory
      if [ -d "$INSTALL_DIR/Bootstrap/$da_version/" ]; then
         cp -rf $INSTALL_DIR/Bootstrap/$da_version/Script_inventory  $PWD
         cat $INSTALL_DIR/Bootstrap/$da_version/requirements.txt | grep -v setuptools | xargs -n 1 pip3 uninstall  -y
         rm -rf ~/.cache/pip
         rm -rf $INSTALL_DIR/Bootstrap/$da_version/*
      fi

      if [[ -d $INSTALL_DIR ]]; then
         rm -rf $INSTALL_DIR
      fi
      rm -rf $PWD/disabled-repos
      rm -rf /repository1
      echo -e "${GREEN}cleaning done.... ${NC}"
   fi
}

function print_next()
{
   echo
   echo -e "${GREEN}####################################################"
   echo -e "source /etc/environment"
   echo -e "Bootstrap python script installed execute as follows"
   echo -e "bootstrap.me -h"
   echo -e "#################################################### ${NC}"
   echo

   #creating version file for DA
   echo -e "${GREEN}HPE Deployment Automation $da_version ${NC}" > $INSTALL_DIR/hpeda-release
}



###################################
# Main
###################################

  if [ $# -ge 3 ]; then
     echo
     usage
     echo
     exit
  fi

  if [[ $1 == "--help" || $1 == "-h" ]]; then
     echo
     usage
     exit 0
  fi

  if [[ $1 == "clean" ]]; then
    if [[ $# -eq 1 ]]; then
      echo -e "${YELLOW} Removing all components. ${NC}"
      cleanup $1
      # Perform removal of all components here
    elif [[ $# -eq 2 ]]; then
      case $2 in
      "awx")
        echo -e "${YELLOW} Cleaning AWX. ${NC}"
        cleanup $1 $2
        ;;
      "gitlab")
        echo -e "${YELLOW}Cleaning GitLab. ${NC}"
        cleanup $1 $2
        ;;
      "nginx")
        echo -e "${YELLOW} Cleaning Nginx. ${NC}"
        cleanup $1 $2
        ;;
      *)
        usage
        exit 1
        ;;
      esac
    else
      usage
      exit 1
    fi
  elif [ "$1" = "download" ]; then
    echo -n -e "${YELLOW}Downloading required packages & images. ${NC}"
    initialize_bootstrap
    proxy
    install_required_setup
    download_dependencies
  elif [ "$1" = "prereqs" ]; then
    echo -e "${YELLOW}Checking system requirements ${NC}"
    initialize_bootstrap
    prereqs
  elif [[ -z "$1" ]]; then
    upgrade_check
    supported_os
    create_user #function to create user - hpeda
    initialize_bootstrap
    setup_hostname
    proxy
    install_required_setup
    download_dependencies
    prereqs
    export -f assign_permissions
    export -f create_venv
    export -f k3s_deploy
    export -f extract_zip
    export -f print_next
    su $da_user -c "assign_permissions"
    su $da_user -c "create_venv"  #function to create venv
    su $da_user -c "k3s_deploy"
    su $da_user -c "extract_zip"
  else
     usage
     exit 1
  fi
