# Automation Scripts

This directory contains the automation scripts that are used in Day0 automation.
Current version of scripts are useful to:
- Generate customized ISO to check for operating system deployment details in USB
- Generate custom kickstart files for each of the baremetal deployment

## Script details

### Custom ISO

The script `usbCustomIso.sh` performs the following operations:
- Extract the base ISO
- Updates the grub configuration
- Repack the ISO
- Push the ISO to a destination folder

Inputs for this script:
- Path for Base ISO
- Location to be pushed after repackaging
- Type of operating system (esxi or rhel or opensles or sles)

#### Supported Operating System ISO's

The -o options for each of the supported Operating System are listed in paranthesis 

- RHEL 8.x (rhel8)
- CentOS 8.x (rhel8)
- ESXi 6.7/7.x (esxi)
- Ubuntu 18.04 (ubuntu)
- Ubuntu 20.04 (ubuntu20)
- openSUSE Leap 15.3/15.4 (opensles)
- SLES 15 SP4/3 (sles)

#### Usage
```
# ./usbCustomIso.sh -i baseimage.iso -p /tmp -o rhel8
```

### Custom Kickstart

The script `ks_to_floppy.sh` performs the following operations:
- Create a floppy disk
- Mount the floppy
- Insert the kickstart
- Unmount the floppy
- Push the floppy to a destination folder

Inputs for this script:
- Path for custom kickstart
- Location to be pushed after repackaging

#### Usage
```
# ./ks_to_floppy.sh -i kickstart.cfg -p /tmp
```
The script `ud_to_floppy.sh` performs the same operation as ks_to_floppy.sh.
The label of floppy disk created here is CIDATA which will be datasource for cloud-init. 
Kicksart.cfg here points to user-data file needed for Cloud-init support for Ubuntu20.

#### Usage
```
# ./ud_to_floppy.sh -i kickstart.cfg -p /tmp
```

The script `yast_to_floppy.sh` performs the same operation as ks_to_floppy.sh.
The label of floppy disk created here is autoinst.xml which will be datasource for autoYast. 
Kicksart.cfg here points to autoinst.xml file needed for Auto Yast support for openSUSE and SUSE Enterprise.

#### Usage
```
# ./yast_to_floppy.sh -i kickstart.cfg -p /tmp
```