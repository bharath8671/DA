#!/bin/bash
##############################################################################
# HPE Deployment Automation
#
# (C) Copyright 2020-2021 Hewlett Packard Enterprise Development LP
#
# Author :  Avinash Jalumuru <avinash.jalumuru@hpe.com>
# Commit :  9c2f9d7
# Date   :  2023-10-09
#
##############################################################################
MOUNT_POINT=/mnt/iso-dvd-$$
TEMP_WORK_DIR=/var/tmp/working-iso-dvd-$$
START=${PWD}

LOG_FILE="/var/log/hpe/customiso.log"
mkdir -p /var/log/hpe/
echo "###################################################################" | tee -a ${LOG_FILE}
echo "$(date +'%F %T')  Starting the script" >>  ${LOG_FILE}

export ISO_FILE=""

function usage() {
   echo "   Usage: $0 -i <iso file> -p <remote path> -o <os type> "
   echo
   echo '   Purpose: This script customizes an ISO file to enable it to look for a kickstart file'
   echo
   echo '   arguments:'
   echo "    -i           ISO file to modify with path"
   echo "    -o           OS support: rhel rhel8 rhel9 rhel_sdflex esxi ubuntu ubuntu20 ubuntu22 opensles sles windows"
   echo
   echo "   optional arguments:"
   echo "    -p           defaults to /var/www/html - path to copy modified file to"
   echo "    -d           directory to copy the drivers into iso root"

   echo
}

function cleanup() {
   echo "Performing cleanup" | tee -a ${LOG_FILE}
   \rm -rf ${MOUNT_POINT}
   \rm -rf ${TEMP_WORK_DIR}

}

# Supported Operating systems
supported_os=("rhel" "rhel8" "rhel9" "rhel_sdflex"
              "esxi"
              "ubuntu" "ubuntu20" "ubuntu22"
              "opensles" "sles"
              "windows")

while getopts ":i:p:o:d:" o; do
    case "${o}" in
        i)
            ISO_FILE=${OPTARG}
            ;;
        p)
            REMOTE_HTTP_PATH=${OPTARG}
            ;;
        o)
            OS_TYPE=${OPTARG}
            ;;
        d)
            DRIVER_DIR=${OPTARG}
            ;;
        *)
           echo "Invalid arguments";
           echo
           usage
           exit -1
            ;;
    esac
done

if [[ "${ISO_FILE}X" == "X" ]]
then
           echo "Invalid arguments : missing -i" | tee -a ${LOG_FILE}
           echo
           usage
           exit -1
fi

if [[ "${REMOTE_HTTP_PATH}X"  == "X" ]]
then
    REMOTE_HTTP_PATH="/var/www/html"
fi


if [[ "${DRIVER_DIR}X" == "x" ]]
then
    DRIVER_DIR=""
fi

if [[ "${OS_TYPE}X"  == "X" ]]
then
    #OS_TYPE="esxi"
    echo "Invalid arguments : missing -o" | tee -a ${LOG_FILE}
    echo
    usage
    exit -1
fi

# Check for support for Operating system
if [[ ! " ${supported_os[@]} " =~ " ${OS_TYPE} " ]]
then
   echo
   echo "ERROR: Given OS TYPE ${OS_TYPE} is not supported" | tee -a ${LOG_FILE}
   echo
   echo "Supported OS: ${supported_os[@]}"| tee -a ${LOG_FILE}
   echo
   exit -1
fi


mkdir -p ${MOUNT_POINT}
mkdir -p ${TEMP_WORK_DIR}

echo "Mounting iso to ${MOUNT_POINT}" | tee -a ${LOG_FILE}
mount -o loop ${ISO_FILE} ${MOUNT_POINT}

if [[ $? -ne 0 ]]
then
        echo "Failed to Mount ISO file to Temp Mount directory" | tee -a ${LOG_FILE}
        exit -1
fi

if [ ${OS_TYPE} == "rhel8" ]
then
   shopt -s dotglob
fi

echo "Copy files to temporary directory ${TEMP_WORK_DIR}" | tee -a ${LOG_FILE}
rsync -avW "${MOUNT_POINT}/" "${TEMP_WORK_DIR}"
if [[ $? -ne 0 ]]
then
    echo "Failed to copy the files from the ISO mount directory to working directory" | tee -a ${LOG_FILE}
    umount ${MOUNT_POINT}
    rmdir ${MOUNT_POINT}
    exit -1
fi

umount ${MOUNT_POINT}
rmdir ${MOUNT_POINT}

umask 022

mkdir -p ${REMOTE_HTTP_PATH}

# Generate iso file name
iso_file_name=`basename ${ISO_FILE}`
custom_iso_file="custom-${iso_file_name}"

case "${OS_TYPE}" in
"esxi")
    echo
    echo "Customizing iso for esxi operating system" | tee -a ${LOG_FILE}
    echo

    FIRST_BOOT_CFG=${TEMP_WORK_DIR}/boot.cfg
    SEC_BOOT_CFG=${TEMP_WORK_DIR}/efi/boot/boot.cfg
    kickstart_param="ks=usb"

    cp ${FIRST_BOOT_CFG} "${FIRST_BOOT_CFG}.old"
    sed -i "s/kernelopt*=.*runweasel.*/kernelopt=runweasel ${kickstart_param}/"  ${FIRST_BOOT_CFG}

    cp ${SEC_BOOT_CFG} "${SEC_BOOT_CFG}+.old"
    sed -i "s/kernelopt*=.*runweasel.*/kernelopt=runweasel ${kickstart_param}/" ${SEC_BOOT_CFG}

    if [ "${DRIVER_DIR}" != "" ]
    then
        echo "Copying file in the directory ${DRIVER_DIR} to iso root directory" | tee -a ${LOG_FILE}
        \cp -vrfp ${DRIVER_DIR}/* ${TEMP_WORK_DIR}
    fi

    genisoimage -relaxed-filenames -J -R -o ${REMOTE_HTTP_PATH}/${custom_iso_file} -b isolinux.bin \
        -c boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table  -eltorito-alt-boot \
        -e efiboot.img -no-emul-boot ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
            echo "ERROR: genisoimage failed to create image" | tee -a ${LOG_FILE}
            cleanup
            exit -1
    fi
    ;;

"rhel")
    echo
    echo "Customizing iso for rhel operating system (rhel7 and equivalent)" | tee -a ${LOG_FILE}
    echo

    LINUX_LABEL=`blkid "${ISO_FILE}" | /bin/grep -o -E 'LABEL="(.*?)"' | cut -d'"' -f2`

    if [[ $? -ne 0 ]]
    then
            echo "Failed to get LABEL from ${ISO_FILE}" | tee -a ${LOG_FILE}
            cleanup
            exit -1
    fi

    FIRST_BOOT_CFG=${TEMP_WORK_DIR}/isolinux/isolinux.cfg
    SEC_BOOT_CFG=${TEMP_WORK_DIR}/EFI/BOOT/grub.cfg

    kickstart_second_param="inst.ks=hd:UUID=3A12-D3C6:\/ks.cfg"
    kickstart_first_param="inst.ks=hd:UUID=3A12-D3C6:\/ks.cfg"

    cp ${FIRST_BOOT_CFG} "${FIRST_BOOT_CFG}.old"
    sed -i -E "s/(append initrd=initrd.img .*$)/\1 ${kickstart_first_param}/" ${FIRST_BOOT_CFG}

    cp ${SEC_BOOT_CFG} "${SEC_BOOT_CFG}.old"
    sed -i -E "s/(linuxefi .*$)/\1 ${kickstart_second_param}/" ${SEC_BOOT_CFG}
    sed -i -E "s/(set default=).+/\1\"0\"/" ${SEC_BOOT_CFG}
    sed -i -E "s/(set timeout=).+/\110/" ${SEC_BOOT_CFG}

    echo "${LINUX_LABEL}"

    mkisofs -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" -b isolinux/isolinux.bin -J -R -l \
        -c isolinux/boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table -eltorito-alt-boot \
        -e images/efiboot.img -no-emul-boot -graft-points -V "${LINUX_LABEL}" ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
        echo "mkisofs failed to create image for ${OS_TYPE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi
    ;;

"ubuntu")
    echo
    echo "Customizing iso for ubuntu 18 operating system" | tee -a ${LOG_FILE}
    echo

    # Ubuntu support only for 18.04 alternative download ISO
    BLOCK_ID=$(blkid "${ISO_FILE}")
    LINUX_LABEL=$(echo ${BLOCK_ID/.*LABEL=} | awk -F\" '{print $2}')
    PRESEED_FILE=${START}/ks.preseed

    if [[ $? -ne 0 ]]
    then
        echo "Failed to get LABEL from ${ISO_FILE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    # Start edit of the ISO file
    cd "${TEMP_WORK_DIR}"

    # Set the language to english
    echo en > ./ubuntu/isolinux/lang

    # Create a preseed file in addition to the ks.cfg to answer debian questions
    cp ${PRESEED_FILE} ./ubuntu/ks.preseed

    # Edit the grub config
    GRUB_FILE="./ubuntu/boot/grub/grub.cfg"
    TXT_FILE="./ubuntu/isolinux/txt.cfg"

    #
    MOUNTPOINT="sdc1"
    KS_LINE="ks=hd:${MOUNTPOINT}:\/ks.cfg"
    KS_FULL_LINE="${KS_LINE} preseed\/file=\/cdrom\/ks.preseed"

    echo "Using mountpoint ${MOUNTPOINT} to floppy device" | tee -a ${LOG_FILE}
    # create backups
    cp ${GRUB_FILE} "${GRUB_FILE}.orig"
    cp ${TXT_FILE} "${TXT_FILE}.orig"

    # Change the default timeout to 10 seconds
    sed -i -E "s/(set timeout=).+/\110/" ${GRUB_FILE}

    # set default menu entry
    sed -i '/timeout.*/a set default=0' ${GRUB_FILE}

    # line number of matching pattern in grub.cfg
    lineNo=$(awk '/Install Ubuntu/{print NR+2}' ${GRUB_FILE} | head -1)
    line=$(sed -n "${lineNo}p" ${GRUB_FILE})
    editedLine=$(echo $line | sed "s/vmlinuz.*/vmlinuz ${KS_FULL_LINE} --/")

    #Change specific line number in file
    execString="sed -i '${lineNo}s#linux.*#${editedLine}#' ${GRUB_FILE}"
    eval ${execString}

    #
    echo "Print changed Grub line"
    sed -n "${lineNo}p" ${GRUB_FILE}

    #Change line in txt.cfg file
    execTXTString="sed -i 's#append.*788#append ${KS_FULL_LINE} #' ${TXT_FILE}"
    eval ${execTXTString}

    TMPMOUNT=/var/tmp/tmpmount-$$
    mkdir -p ${TMPMOUNT}
    cd ${TMPMOUNT}

    gzip -dc ${TEMP_WORK_DIR}/ubuntu/install/initrd.gz | cpio -id
    mkdir -p ./media/${MOUNTPOINT}
    find . | cpio -o -c -R root:root | gzip -9 > ${TEMP_WORK_DIR}/ubuntu/install/initrd.gz

    # get back
    cd ${TEMP_WORK_DIR}
    rm -rf ${TMPMOUNT}

    # Rebuild the iso
    mkisofs -U -A "${LINUX_LABEL}" -V "${LINUX_LABEL}" -volset "${LINUX_LABEL}" -J -r -v -T \
       -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" -b isolinux/isolinux.bin -c isolinux/boot.cat \
       -no-emul-boot -boot-load-size 4 -boot-info-table -eltorito-alt-boot \
       -e boot/grub/efi.img -no-emul-boot . | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
        echo "mkisofs failed to create image" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    cd ${START}

    ;;

"ubuntu20"|"ubuntu22")
    echo
    echo "Customizing iso for ubuntu 20/22 operating system (cloud-init based)" | tee -a ${LOG_FILE}
    echo
    BLOCK_ID=$(blkid "${ISO_FILE}")
    LINUX_LABEL=$(echo ${BLOCK_ID/.*LABEL=} | awk -F\" '{print $2}')

    if [[ $? -ne 0 ]]
    then
        echo "Failed to get LABEL from ${ISO_FILE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    # Edit the grub config
    GRUB_FILE="${TEMP_WORK_DIR}/ubuntu/boot/grub/grub.cfg"
    LB_FILE="${TEMP_WORK_DIR}/ubuntu/boot/grub/loopback.cfg"

    echo  "Adding autoinstall parameter to kernel command line..." | tee -a ${LOG_FILE}
    if [ "${OS_TYPE}" == "ubuntu20" ]
    then
        TXT_FILE="${TEMP_WORK_DIR}/ubuntu/isolinux/txt.cfg"
        sed -i -e 's/---/ autoinstall  fsck.mode=skip  ds=nocloud;fs_label=cidata  ---/g' "${TXT_FILE}"
    fi
    sed -i -e 's/---/ autoinstall  fsck.mode=skip  ds=nocloud\\\;fs_label=cidata  ---/g' "${GRUB_FILE}"
    sed -i -e 's/---/ autoinstall  fsck.mode=skip  ds=nocloud\\\;fs_label=cidata  ---/g' "${LB_FILE}"
    echo " Added parameter to UEFI and BIOS kernel command lines." | tee -a ${LOG_FILE}

    # Change the default timeout to 10 seconds
    sed -i -E "s/(set timeout=).+/\110/" ${GRUB_FILE}

    # set default menu entry
    sed -i '/timeout.*/a set default=0' ${GRUB_FILE}

    # Rebuild the iso
    if [ "${OS_TYPE}" == "ubuntu20" ]
    then
    mkisofs -U -A "${LINUX_LABEL}" -V "${LINUX_LABEL}" -volset "${LINUX_LABEL}" -J -joliet-long \
       -r -v -T -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" -b isolinux/isolinux.bin \
       -c isolinux/boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table \
       -eltorito-alt-boot -e boot/grub/efi.img -no-emul-boot ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}
    else
        echo "Generating iso create command for ubuntu 22" | tee -a ${LOG_FILE}
        temp_file=$(mktemp)
        xorriso -indev "${ISO_FILE}" -report_el_torito as_mkisofs > $temp_file
        echo "Temporary file $temp_file contains the options for iso generation" | tee -a ${LOG_FILE}
        execString="xorriso -as mkisofs -r -o ${REMOTE_HTTP_PATH}/${custom_iso_file} $(cat $temp_file | tr '\n' ' ') ${TEMP_WORK_DIR}"
        echo $execString
        eval ${execString}
        #xorriso -as mkisofs -r -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" \
        #    $(cat $temp_file | tr '\n' ' ') ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}
    fi

    if [[ $? -ne 0 ]]
    then
        echo "failed to create image for ${OS_TYPE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi
    ;;

"rhel8"|"rhel9"|"rhel_sdflex")
    echo
    echo "Customizing iso for rhel 8/9 operating system (rocky8/9)" | tee -a ${LOG_FILE}
    echo
    BLOCK_ID=$(blkid "${ISO_FILE}")
    LINUX_LABEL=$(echo ${BLOCK_ID/.*LABEL=} | awk -F\" '{print $2}')

    if [[ $? -ne 0 ]]
    then
        echo "Failed to get LABEL from ${ISO_FILE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    if [ "${DRIVER_DIR}" != "" ]
    then
        echo "Copying file in the directory ${DRIVER_DIR} to iso root directory" | tee -a ${LOG_FILE}
        \cp -vrfp ${DRIVER_DIR}/* ${TEMP_WORK_DIR}
    fi

    # boot line
    KS_LINE="inst.ks=hd:LABEL=OEMDRV:\/ks.cfg"

    if [ "${OS_TYPE}" == "rhel_sdflex" ];
    then
        # Sdflex uses pmem devices to mount iso file present using HTTP Boot
        KS_LINE="inst.ks=hd:LABEL=OEMDRV:\/ks.cfg inst.repo=hd:pmem0"
    fi

    # Edit the grub config
    GRUB_FILE="${TEMP_WORK_DIR}/EFI/BOOT/grub.cfg"
    ISOLINUX_FILE="${TEMP_WORK_DIR}/isolinux/isolinux.cfg"

    # create backups
    cp ${GRUB_FILE} "${GRUB_FILE}.orig"
    cp ${ISOLINUX_FILE} "${ISOLINUX_FILE}.orig"

    # Change the default timeout to 10 seconds
    sed -i -E "s/(set timeout=).+/\110/" ${GRUB_FILE}

    # set default menu entry
    sed -i 's/set default.*/set default="0"/' ${GRUB_FILE}

    # line number of matching pattern in grub.cfg
    lineNo=$(awk '/Install Red Hat Enterprise/{print NR+1}' ${GRUB_FILE} | head -1)

    #Change specific line number in file
    execString="sed -i '${lineNo}s#quiet#${KS_LINE}#' ${GRUB_FILE}"
    eval ${execString}

    echo "Print changed Grub line"
    sed -n "${lineNo}p" ${GRUB_FILE}

    # change timeout
    sed -i 's/timeout.*/timeout 10/' ${ISOLINUX_FILE}
    sed -i 's/default.*/default linux/' ${ISOLINUX_FILE}

    # line number of matching pattern in isolinux.cfg
    lineNo=$(awk '/Install Red Hat Enterprise/{print NR+2}' ${ISOLINUX_FILE} | head -1)

    # Change the isolinux.cfg file
    execTXTString="sed -i '${lineNo}s#quiet#${KS_LINE}#' ${ISOLINUX_FILE}"
    eval ${execTXTString}

    mkisofs -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" -b isolinux/isolinux.bin -J -joliet-long \
        -R -l -c isolinux/boot.cat -no-emul-boot -boot-load-size 4 -boot-info-table \
        -eltorito-alt-boot -e images/efiboot.img -no-emul-boot -graft-points \
        -V ${LINUX_LABEL} ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
        echo "mkisofs failed to create image for ${OS_TYPE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    #isohybrid --uefi ${REMOTE_HTTP_PATH}/${custom_iso_file}
    ;;

"sles"|"opensles")
    echo
    echo "Customizing iso for sles/opensles operating system" | tee -a ${LOG_FILE}
    echo

    LINUX_LABEL=`blkid "${ISO_FILE}" | /bin/grep -o -E 'LABEL="(.*?)"' | cut -d'"' -f2`

    if [[ $? -ne 0 ]]
    then
        echo "Failed to get LABEL from ${ISO_FILE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi

    # Create addon_product.xml file in addition to the autoinst.xml to answer SLES questions
    if [[ ${OS_TYPE} == "sles" ]]
    then
        ADD_ON_PRODUCT_XML_FILE=${START}/add_on_products.xml
        cp ${ADD_ON_PRODUCT_XML_FILE} ${TEMP_WORK_DIR}
        echo "Addon_product.xml file add to Custom ISO " | tee -a ${LOG_FILE}
    fi

    FIRST_BOOT_CFG=${TEMP_WORK_DIR}/boot/x86_64/loader/isolinux.cfg
    SEC_BOOT_CFG=${TEMP_WORK_DIR}/EFI/BOOT/grub.cfg

    kickstart_param="autoyast=usb:\/\/\/autoinst.xml"
    persistent_interfaces="net.ifnames=1"

    cp ${FIRST_BOOT_CFG} "${FIRST_BOOT_CFG}.old"
    sed -i "s/default harddisk/default linux/"  ${FIRST_BOOT_CFG}
    sed -i "s/append initrd=initrd splash=silent showopts.*/append initrd=initrd splash=silent showopts ${kickstart_param}/"  ${FIRST_BOOT_CFG}

    cp ${SEC_BOOT_CFG} "${SEC_BOOT_CFG}+.old"
    sed -i "s/timeout=60/timeout=5/" ${SEC_BOOT_CFG}
    sed -i "s/linux \/boot\/x86_64\/loader\/linux splash=silent$/linux \/boot\/x86_64\/loader\/linux splash=silent ${kickstart_param} ${persistent_interfaces}/" ${SEC_BOOT_CFG}

    xorriso -as mkisofs -relaxed-filenames -J -R -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" \
        -b boot/x86_64/loader/isolinux.bin -c boot.cat -no-emul-boot -boot-load-size 4 \
        -boot-info-table -eltorito-alt-boot -e boot/x86_64/efi -no-emul-boot \
        ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
        echo "xorriso failed to create image for ${OS_TYPE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi
    ;;

"windows")
    echo
    echo "Customizing iso for windows operating system" | tee -a ${LOG_FILE}
    echo

    # Remove the bootfix.bin not skip user interaction
    rm -rf "${TEMP_WORK_DIR}/boot/bootfix.bin"

    # Files (like drivers) to be copied to the root directory of ISO
    if [ "${DRIVER_DIR}" != "" ]
    then
        echo "Copying file in the directory ${DRIVER_DIR} to iso root directory" | tee -a ${LOG_FILE}
        \cp -vrfp ${DRIVER_DIR}/* ${TEMP_WORK_DIR}
    fi

    xorrisofs -o "${REMOTE_HTTP_PATH}/${custom_iso_file}" -no-emul-boot -b "boot/etfsboot.com" \
        -boot-load-size 8 -eltorito-alt-boot -no-emul-boot -e "efi/microsoft/boot/efisys_noprompt.bin" \
        -boot-load-size 1 -iso-level 4 ${TEMP_WORK_DIR} 2>&1 | tee -a ${LOG_FILE}

    if [[ $? -ne 0 ]]
    then
        echo "xorriso failed to create image for ${OS_TYPE}" | tee -a ${LOG_FILE}
        cleanup
        exit -1
    fi
    ;;

*)
       echo "OS Type specified ${OS_TYPE} is not supported" | tee -a ${LOG_FILE}
       cleanup
       exit 1
    ;;
esac

cleanup

echo "Generated custom ISO is located at: ${REMOTE_HTTP_PATH}/${custom_iso_file}" | tee -a ${LOG_FILE}
echo "$(date +'%F %T')  Script completed" >>  ${LOG_FILE}
