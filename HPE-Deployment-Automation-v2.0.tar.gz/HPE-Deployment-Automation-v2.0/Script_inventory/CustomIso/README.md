# Custom ISO

Scripts in this path are used to customize ISO file.

| File              | Description                                                     |
|-------------------|-----------------------------------------------------------------|
| usbCustomIso.sh   | Script to edit ISO boot parameters to read kickstart from USB   |
| ks_to_floppy.sh   | Script to insert kickstart file to USB                          |
| ud_to_floppy.sh   | Script to insert kickstart file to USB for cloud-init user-data |
| yast_to_floppy.sh | Script to insert kickstart file to USB for auto yast xml        |
| answer_to_floppy.sh | Script to insert kickstart file to USB for autounttend xml    |
| ks_base.img       | Base USB image                                                  |
| KS.CFG            | Kickstart config file                                           |

Kickstart in this example are used for VMware ESXi. However, the same process can be applied for any Linux or windows operating system

## Script details

The script `usbCustomIso.sh` performs the following operations:
- Extract the base ISO
- Updates the grub configuration
- Repack the ISO
- Push the ISO to a destination folder

Inputs for this script:
- Path for Base ISO
- Location to be pushed after repackaging
- Type of operating system (esxi or rhel or windows)

#### Usage
```
# ./usbCustomIso.sh -i baseimage.iso -p /tmp -o rhel

```
Note: Added -joliet-long flag for OS support rhel8 that allows Joliet filenames to be up to 103 Unicode characters, instead of 64.


#### Supported OS
- Redhat Enterprise Linux (rhel, rhel8, rhel9, rhel_sdflex)
- VMware vSphere (esxi)
- Ubuntu Operating System (ubuntu, ubuntu20, ubuntu22)
- SUSE Enterprise Linux (opensles, sles)
- Windows Server Operating System (windows)

### Custom Kickstart

`ks_to_floppy.sh` is used when we provision OS using kickstart/answer files.
`ud_to_floppy.sh` is used when we do provisioning using cloud-init user-data and meta-data files.
`yast_to_floppy.sh` is used when we do provision using autoinst.xml.
`answer_to_floppy.sh` is used when we do provision using autounttend.xml.
The scripts either `ks_to_floppy.sh` or `ud_to_floppy.sh` or `yast_to_floppy.sh` or `answer_to_floppy.sh` performs same set of following operations :
- Create a floppy disk
- Mount the floppy
- Insert the kickstart
- Unmount the floppy
- Push the floppy to a destination folder

Inputs for this script:
- Path for custom kickstart
- Location to be pushed after repackaging


#### Usage
```
# ./ks_to_floppy.sh -k kickstart.cfg -p /tmp
```

#### Usage
```
# ./ud_to_floppy.sh -k kickstart.cfg -p /tmp
```

#### Usage
```
# ./yast_to_floppy.sh -k autoinst.xml -p /tmp
```

#### Usage
```
# ./answer_to_floppy.sh -k autounttend.xml -p /tmp
```

# Custom partitioning for preseed based ubuntu deployments.

Deployment of Ubuntu operating system does not depend on kickstart alone.
It requires preseed (cloud-init for newer version) to install operating system.
These files can perform customize configuration during deployment.

There are two sample ks.preseed files:
one with basic configuration and the other with customized LVM.
`ks.preseed` is the only file used by usbCustomIso.sh to generate a custom ubuntu ISO.

In order to use customize LVM, perform the following actions:
1. Change the contents of `ks.preseed.lvm` based on environment like disk size, mount points, partition size, etc.,
2. Take backup of `ks.preseed` file
2. Replace ks.preseed with ks.preseed.lvm  (`cp ks.preseed.lvm ks.preseed`)
3. Generate the ubuntu iso using `usbCustomIso.sh` as mentioned in the [usage](#script-details)

More details from sample `ks.preseed.lvm` file:

1. `1116` is the size of the logical disk that to be selected during the OS deployment.
   Replace this value based on the environment
2. LVM attributes, mountpoint, etc., that are used from below table.
   Change values in ks.preseed.lvm based on environment

| VGName    | LV namei     | Mount Point    |   Size   | Filesystem type |
| --------- | ------------ | -------------- | -------- | --------------- |
| sda1      |              | /boot          | 1GB      | ext4  |
| sda2      |              | /boot/efi      | 512mb    | fat32 |
| ubuntu-vg | lv-root      | /              | 20GB     | ext4  |
| ubuntu-vg | lv-swap      | SWAP           | 16GB     | swap  |
| ubuntu-vg | lv-var       | /var           | 20GB     | ext4  |
| ubuntu-vg | lv-var-tmp   | /var/tmp       | 5GB      | ext4  |
| ubuntu-vg | lv-var-log   | /var/logi      | 25GB     | ext4  |
| ubuntu-vg | lv-var-audit | /var/log/audit | 10GB     | ext4  |
| ubuntu-vg | lv-tmp       | /tmp           | 5GB      | ext4  |
| ubuntu-vg | lv-home      | /home          | 5GB      | ext4  |
| ubuntu-vg | lv-opt       | /opt           | 25GB     | ext4  |

# Custom partitioning for Ubuntu using user-data file

In order to use customize LVM, perform the following actions:
1. Change the contents of `Ansible_Playbooks/Day0/roles/hpe-bm-kickstart/ubuntu20_lvm_ks.cfg.j2` based on environment like disk size, mount points, partition size, etc.,
2. Take backup of `Ansible_Playbooks/Day0/roles/hpe-bm-kickstart/ubuntu20_ks.cfg.j2` file
3. Replace `Ansible_Playbooks/Day0/roles/hpe-bm-kickstart/ubuntu20_ks.cfg.j2` with `Ansible_Playbooks/Day0/roles/hpe-bm-kickstart/ubuntu20_lvm_ks.cfg.j2`  (`cp ubuntu20_lvm_ks.cfg.j2 ubuntu20_ks.cfg.j2`)
4. Generate the ubuntu iso using `usbCustomIso.sh` as mentioned in the [usage](#script-details)


# Customization of OpenSUSE/SUSE iso deployments.

1. OpenSUSE Customization:
    - Deploying of OpenSUSE operating system does not depend on add_on_product.xml file. 
    - For openSUSE, adding **`net.ifnames=1`** in grub and isolinux files for the persistent interfaces.
    - Only it requires autoinst.xml kickstart file to install and deploy the operating system on hardware.

2. SUSE Enterprise Customization:
    - Deploying of SUSE Enterprise operating system depends on add_on_product.xml file.
    - For SUSE, adding **`net.ifnames=1`** in grub and isolinux files for the persistent interfaces.
    - Generate SUSE Enterprise iso using `usbCustomIso.sh` as mentioned in the [usage](#script-details)
    - Add also it requires autoinst.xml kickstart file to install the operating system.
    - In add_on_products.xml file contains repository path of the base system to install the packages for Operating system.
   ```xml
   <?xml version="1.0"?>
   <add_on_products xmlns="http://www.suse.com/1.0/yast2ns" xmlns:config="http://www.suse.com/1.0/configns">
    <product_items config:type="list">
     <product_item>
      <url>relurl:////</url>
      <path>/Module-Basesystem</path>
     </product_item>
    </product_items>
   </add_on_products>

   ```


# Customization of Windows iso deployments.

1. Windows Customization for **SD_Flex servers**:
   
   - To customize the windows iso file along with the drivers by passing the drivers with an option of -d and drivers path.
   - Example:
      > ./usbCustomIso.sh -i baseimage.iso -p /tmp -o windows -d /path/of/drivers
