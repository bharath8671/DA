#!/bin/bash
##############################################################################
# HPE Deployment Automation
#
# (C) Copyright 2020-2021 Hewlett Packard Enterprise Development LP
#
# Author :  Avinash Jalumuru <avinash.jalumuru@hpe.com>
# Commit :  9c2f9d7
# Date   :  2023-10-09
#
##############################################################################

while getopts ":k:p:" o; do
    case "${o}" in
        k)
            KICKSTART_FILE=${OPTARG}
            ;;
        p)
            REMOTE_HTTP_PATH=${OPTARG}
            ;;
        *)
           echo "Error: invalid arguments";
           echo "-k kickstart_file"
           exit -1
            ;;
    esac
done

if [[ "${KICKSTART_FILE}X"  == "X" ]]
then
           echo "Error: invalid arguments";
           echo "-k kickstart_file -p remote_http_path"
           exit -1
fi

if [[ "${REMOTE_HTTP_PATH}X"  == "X" ]]
then
    REMOTE_HTTP_PATH="/var/www/html"
fi

umask 022

TEMP_DIR="/tmp/insert-dir-$$"
CHECK_FILE="/tmp/insert-check-$$"

uuid=$(hexdump -n 16 -e '4/4 "%08X" 1 "\n"' /dev/random)
USB_IMAGE=${uuid}.img

DIR_PATH=$(dirname $0)

\cp ${DIR_PATH}/ks_base.img ${USB_IMAGE}

kpartx -av ${USB_IMAGE} > ${CHECK_FILE}


if [ $? -ne 0 ]
then
   echo "Error: Failed to create usb stick"
   exit -1
fi

loopdev=$(grep -o "\w*loop\w*" ${CHECK_FILE})
#echo "Loop device: $loopdev"

mkdir -p ${TEMP_DIR}

mount /dev/mapper/${loopdev} ${TEMP_DIR}
\cp ${KICKSTART_FILE} ${TEMP_DIR}/user-data
\cp meta-data ${TEMP_DIR}/meta-data

umount ${TEMP_DIR}
fatlabel /dev/mapper/${loopdev} cidata
kpartx -d ${USB_IMAGE}


\rm -r ${TEMP_DIR}
\rm -r ${CHECK_FILE}

mkdir -p ${REMOTE_HTTP_PATH}
\cp -f ${USB_IMAGE} ${REMOTE_HTTP_PATH}
echo "${USB_IMAGE}"

\rm -r ${USB_IMAGE}
